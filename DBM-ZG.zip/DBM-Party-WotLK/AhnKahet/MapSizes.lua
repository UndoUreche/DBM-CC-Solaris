DBM:RegisterMapSize("Ahnkahet", 1, 972.417968747, 648.279022217) -- Ahn'Kahet
